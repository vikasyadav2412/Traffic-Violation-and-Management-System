package com.example.violation

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button

class UserDashboardActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_user_dashboard)

        val btnViewViolations = findViewById<Button>(R.id.btnViewViolations)
        val btnPayFine = findViewById<Button>(R.id.btnPayFine)
        val btnViolationHistory = findViewById<Button>(R.id.btnViolationHistory)

        btnViewViolations.setOnClickListener {
            val intent = Intent(this, ViewViolationsActivity::class.java)
            startActivity(intent)
        }

        btnPayFine.setOnClickListener {
            val intent = Intent(this, PayFineActivity::class.java)
            startActivity(intent)
        }

        btnViolationHistory.setOnClickListener {
            val intent = Intent(this, ViolationHistoryActivity::class.java)
            startActivity(intent)
        }
    }
}